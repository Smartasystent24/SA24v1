export default function App() {
  return (
    <div style={{
      fontFamily: 'sans-serif',
      textAlign: 'center',
      padding: '4rem'
    }}>
      <h1 style={{ fontSize: '2.5rem', color: '#4F46E5' }}>SmartAsystent24</h1>
      <p style={{ fontSize: '1.2rem', maxWidth: 600, margin: '2rem auto' }}>
        Twój osobisty AI-asystent do umawiania wizyt i odbierania telefonów.
      </p>
      <ul style={{ listStyle: 'none', padding: 0, fontSize: '1rem' }}>
        <li>✅ Odbiera telefon</li>
        <li>✅ Umawia wizyty</li>
        <li>✅ Wysyła SMS z potwierdzeniem</li>
      </ul>
      <button style={{
        marginTop: '2rem',
        padding: '0.75rem 2rem',
        fontSize: '1rem',
        backgroundColor: '#4F46E5',
        color: 'white',
        border: 'none',
        borderRadius: '0.5rem'
      }}>
        Przetestuj za darmo
      </button>
    </div>
  );
}